﻿namespace IronOcr
{
    internal class AutoOcr
    {
        public AutoOcr()
        {
        }
    }
}