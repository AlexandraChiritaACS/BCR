﻿using System;
using System.Collections.Generic;
using System.Text;

using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using MySql.Data.MySqlClient;

namespace RailTraceMobile.Views
{
    class ConnToAzure
    {
        public int selectResults(string s, string search1, string search2)
        {
            int found = 1;

            try
            {
               
                MySqlConnection connessione = new MySqlConnection("Server=tcp:careernet.database.windows.net,1433;Initial Catalog=Career_Test_Data;Persist Security Info=False;User ID=alex_admin;Password=Mamasita-123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
                connessione.Open();
                MySqlCommand cmd = new MySqlCommand(s, connessione);
                MySqlDataReader dr = cmd.ExecuteReader();

                int i = 0;
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (dr.GetString(4).ToLower().Contains(search1) && dr.GetString(5).ToLower().Contains(search2)) ;
                        return 1;
                    }
                }

                dr.Close();
                connessione.Close();
                if (i == 0)
                {
                    found = 0;
                }


            }
            catch (Exception e)
            {
                found = 1;
            }
            
            return found;
        }
    }
}
