﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;

namespace RailTraceMobile.Views
{
    class ConnectToAzure
    {
        public int selectResults(string s, string search)
        {
            int found = 1;

            try
            {

                SqlConnection connessione = new SqlConnection("Server=tcp:careernet.database.windows.net,1433;Initial Catalog=Career_Test_Data;Persist Security Info=False;User ID=alex_admin;Password=Mamasita-123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
                connessione.Open();
                SqlCommand cmd = new SqlCommand(s, connessione);
                SqlDataReader dr = cmd.ExecuteReader();

                int i = 0;
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        if (dr.GetString(2).ToLower().Contains(search)) ;
                        return 1;
                    }
                }

                dr.Close();
                connessione.Close();
                if (i == 0)
                {
                    found = 0;
                }


            }
            catch (SqlException e)
            {

            }

            return found;
        }
    }
}
