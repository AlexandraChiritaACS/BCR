﻿using Microsoft.ProjectOxford.Face;
using Microsoft.ProjectOxford.Face.Contract;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace RailTraceMobile.Views
{
    class CheckData
    {
        private readonly IFaceServiceClient faceServiceClient = new FaceServiceClient("78396eceef024cacb6cb12186cf8ee3e", @"https://westeurope.api.cognitive.microsoft.com/face/v1.0");
        static int fou = 0;
        static async void initPersonGroup()
        {
            string SubscriptionKey = "78396eceef024cacb6cb12186cf8ee3e";
            // Use your own subscription endpoint corresponding to the subscription key.
            string SubscriptionRegion = "https://westeurope.api.cognitive.microsoft.com/face/v1.0/";
            FaceServiceClient faceServiceClient = new FaceServiceClient(SubscriptionKey, SubscriptionRegion);
            string personGroupId = "myfriends";

            await faceServiceClient.CreatePersonGroupAsync(personGroupId, "My Friends1");


            CreatePersonResult friend1 = await faceServiceClient.CreatePersonAsync(
                // Id of the PersonGroup that the person belonged to
                personGroupId,
                // Name of the person
                "Alexandra_Chirita_2981014170042"
            );

            const string friend1ImageDir = @"C:\Users\ionch\Pictures\UserFolder";

            foreach (string imagePath in Directory.GetFiles(friend1ImageDir, "*.jpg"))
            {
                using (Stream s = File.OpenRead(imagePath))
                {
                    // Detect faces in the image and add to Anna
                    await faceServiceClient.AddPersonFaceAsync(
                        personGroupId, friend1.PersonId, s);
                }
            }



            // Training the neural network
            TrainingStatus trainingStatus = null;
            for (int i = 0; i <= 1000; i++)
            {
                trainingStatus = await faceServiceClient.GetPersonGroupTrainingStatusAsync(personGroupId);

                if (trainingStatus.Status != Status.Running)
                {
                    break;
                }
            }

            string testImageFile = @"C:\Users\ionch\Pictures\UserFolder\Buletin.jpg";

            using (Stream s = File.OpenRead(testImageFile))
            {
                var faces = await faceServiceClient.DetectAsync(s);
                var faceIds = faces.Select(face => face.FaceId).ToArray();

                var results = await faceServiceClient.IdentifyAsync(personGroupId, faceIds);

                foreach (var identifyResult in results)
                {
                    //Console.WriteLine("Result of face: {0}", identifyResult.FaceId);

                    if (identifyResult.Candidates.Length == 0)
                    {
                        
                        Debug.WriteLine("Answer: Person not identified.");
                        fou = 0;
                        // Adaugi o notificare ca persoana nu este identificata
                        // Blur person's face
                    }
                    else
                    {
                        // Get top 1 among all candidates returned
                        var candidateId = identifyResult.Candidates[0].PersonId;
                        var person = await faceServiceClient.GetPersonAsync(personGroupId, candidateId);
                        //Console.WriteLine("Identified as {0}", person.Name);
                        // Confirmi recunoasterea persoanei
                        // Highlight person's face.
                        Debug.WriteLine ("Answer: Open Access.");
                        fou = 1;
                    }
                }
            }

            
        }

        // Metoda care incarca un fisier in Azure Blobs
        public void checkIfDataIsGenuine()
        {
            initPersonGroup();
            if (fou == 1)
            {
                //var Ocr = new System.Object.Ocr.AutoOcr();
                var Result = "IDROUDEACONU<<ANDREEA<CARINA<<<<<<<<XR622660<6ROU9903090F250309920900221";// Ocr.(@"C:\Users\ionch\Pictures\UserFolder\Buletin.jpg");
                var index = Result.IndexOf("IDROU");
                //Console.WriteLine(Result.Text);
                //Console.WriteLine(index);
                string MRZ = Result.Substring(index, 74);
                Console.WriteLine(MRZ);
                var x = Console.Read();
                string CurrentLastName = "", CurrentSurName = "", CurrentBirth = "", CurrentMRZ = "";
                CurrentBirth = CurrentBirth.Replace("-", "").Replace(".", "").Replace(":", "").Replace("T", "").Substring(0, 8);
                if (CurrentLastName.Equals(MRZ.Substring(5, CurrentLastName.Length))) { }
                //actualizez MRZ in BD
                else if (CurrentSurName.Equals(MRZ.Substring(5 + CurrentLastName.Length + 2, CurrentSurName.Length))) { }
                //actualizez MRZ in BD
                else if (CurrentBirth.Equals("19" + MRZ.Substring(49, 6))) { }
                // actualizez MRZ in BD
                try
                {
                    SqlConnection con = new SqlConnection("Server=tcp:careernet.database.windows.net,1433;Initial Catalog=Career_Test_Data;Persist Security Info=False;User ID=alex_admin;Password=Mamasita-123;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
                    DataSet ds = new DataSet();
                    con.Open();
                    SqlCommand cmd = new SqlCommand(" UPDATE client  SET MRZ=@MRZ)");
                    cmd.Parameters.AddWithValue("@MRZ", MRZ);

                    cmd.ExecuteNonQuery();
                }
                catch { }
            }
        }

        
    }
}
