﻿using RailTraceMobile.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace RailTraceMobile.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class LoginPage : ContentPage
	{
        App p;
		public LoginPage ()
		{
			InitializeComponent ();
		}

        public LoginPage(App p)
        {
            this.p = p;
            InitializeComponent();
        }

        public async void SignInProcedure(object sender, EventArgs e)
        {
            //User user = new User(Entry_Username.Text, Entry_Password.Text);
            ConnToAzure c = new ConnToAzure();
            int found = c.selectResults(@"select * from clients", Entry_Username.Text, Entry_Password.Text);
            //if (user.checkInformation())
            //{
            //try
            //{
            //await Navigation.PushAsync(new NavigationPage(new RailTraceMobile.MenuPage()));

            //await Application.Current.MainPage.Navigation.PushAsync(new MenuPage());
            //}
            if (found == 1)
            {
                p.MainPage = new Admin(p);
            }
                /* catch
                 {
                     DisplayAlert("Login", "Not Ok Page", "Oke");
                 }*/

            //}

            else
            {
                DisplayAlert("Login", "User Not Found", "Oke");
            }
        }
	}
}