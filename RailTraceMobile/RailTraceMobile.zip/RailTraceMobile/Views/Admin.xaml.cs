﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace RailTraceMobile.Views
{
	[XamlCompilation(XamlCompilationOptions.Compile)]
	public partial class Admin : ContentPage
	{
        App p;
        int not = 1;
        public Admin ()
		{
			InitializeComponent ();
		}

        public Admin (App p)
        {
            this.p = p;
            InitializeComponent();
        }

        public void Tasks (object sender, EventArgs e)
        {
            // Deschidem o pagina pentru a incarca si a analiza o imagine de pe buletin
            not = 1;
            p.MainPage = new PhotoAnalysis(p);
            not = 1;
        }

        public void DisplayMap(object sender, EventArgs e)
        {
            // Metoda care sa deschida o pagina in care sa poti vedea harta unei locatii selectate
            not = 1;
        }

        public void ShowStatistics (object sender, EventArgs e)
        {
            // Metoda care deschide o pagina cu grafice - incearca sa folosesti experiments din azure
        }

        public void Notifications (object sender, EventArgs e)
        {
            // Metoda care arata o lista cu notificarile de lucru ale angazatului - incearca sa o faci dinamica (sa i se afiseze pe ecran)
            if (not == 1)
            {
                Application.Current.MainPage.DisplayAlert("Notifications", "You updated the Identification Data", "Ok");
            }

            else
            {
                Application.Current.MainPage.DisplayAlert("Notifications", "No action.", "Ok");
            }
        }

        public void DisplayDoc (object sender, EventArgs e)
        {
            // Metoda care afiseaza o pagina cu documentatia problemei
        }

        public void ProfileEdit (object sender, EventArgs e)
        {
            // Metoda care deschide pagina de profil a angajatului (isi poate seta situatia - busy, available, on holiday etc.)
            //DisplayAlert("Username: ");
            Application.Current.MainPage.DisplayAlert("Profile", "Username: AlexandraPC \n" +
                                                                "Account_Number: RO17RNCB0278000000580004\n" +
                                                                "Status: Active", "Ok");
        }
    }
}