﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RailTraceMobile.Models
{
    class Constants
    {
        public static bool IsDev = true;
    }
}
